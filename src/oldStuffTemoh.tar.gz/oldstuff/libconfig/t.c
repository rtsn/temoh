/*
 * Stolen from:
 * http://jpmens.net/2009/09/17/reading-configuration-files-with-libconfig/
*/
#include <stdio.h>
#include <stdlib.h>
#include <libconfig.h>

//int readConfig(int verbose,uint8_t publicKey[PUBKEYLEN],unsigned char hmacKey[HMACLEN],char expectedIP[16], int *port);


int main(int argc, char **argv) {
	config_t cfg, *cf;
	const char *tmpHmacKey;
	const char *tmpExpectedIP;
    int tmpPort;
    const config_setting_t *metaPubKey;
    
	cf = &cfg;
	config_init(cf);

	if (!config_read_file(cf, "temoh.cfg")) {
		fprintf(stderr, "%s:%d - %s\n",
			config_error_file(cf),
			config_error_line(cf),
			config_error_text(cf));
		config_destroy(cf);
		return(EXIT_FAILURE);
        //return 0;
	}

	if (config_lookup_string(cf, "hmacKey", &tmpHmacKey)) {
		printf("hmacKey: %s\n", tmpHmacKey);
    }
	else { 
		printf("hmacKey is not defined\n");
        // return 0;
    }
 
	if (config_lookup_string(cf, "expectedIP", &tmpExpectedIP)) {
		printf("expectedIP: %s\n", tmpExpectedIP);
        //if case == 0 
    }
	else { 
		printf("expectedIP is not defined or not set to 0\n");
        // return 0;
    }
 
    if (config_lookup_int(cf, "port", &tmpPort)) {
        printf("port: %d\n", tmpPort);
    }
    else {
        printf("port number is not defined\n");
        // return 0
    }

    metaPubKey = config_lookup(cf, "pubKey");

    if (metaPubKey) {
        for (int n = 0; n < config_setting_length(metaPubKey); n++) {
		    printf("%d ",config_setting_get_int_elem(metaPubKey, n));
        //publicKey[n] = config_setting_get_int_elem(pubKey, n)

	    }
        printf("\n");
    }
    else {
        printf("pubKey is not defined\n");
        //return 0
    }
	config_destroy(cf);

    /*
    if (verbose) {
      //print stuff
    }
    return 1;
    */

	return 0;
}
