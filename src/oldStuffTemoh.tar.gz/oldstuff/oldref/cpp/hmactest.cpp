
#include "sha256.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main() {
	const uint8_t hmacKey[] = "1234567890";

	char msg[16] = {0};

	unsigned char* digest;

	Sha256.initHmac(hmacKey,10);

//      for (int j = 0; j < 16; j++) {
//        Sha256.write(msg[j]);
//      }
//      byta ut till Sha256.print(...) ???


			Sha256.print(msg);
      memcpy(digest, Sha256.resultHmac(), sizeof(uint8_t)*32);  

	for(int i = 0; i < 32; i++) {
		printf("%d ",digest[i]);
	}

	return 0;
}
