/*
https://www.abc.se/~m6695/udp.html
*/

#include <arpa/inet.h>
#include <netinet/in.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <unistd.h>
#include <stdlib.h> // to avoid warning on diep, exit(1) incompatible


#include <string.h> /* to avoid memset warning memset */

#define BUFLEN 16 //later on 16+32+64
#define NPACK 10000
#define PORT 8888
void diep(char *s) { //display error
	perror(s);
	exit(1);
}

int main(void) {
	int t;
	struct sockaddr_in si_me, si_other;
	int s, i, slen=sizeof(si_other);
	//char buf[BUFLEN];
  uint8_t buf[BUFLEN];

	if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP))==-1) {
		diep("socket");
	}
	memset((char *) &si_me, 0, sizeof(si_me));

	si_me.sin_family = AF_INET;
	si_me.sin_port = htons(PORT);
	si_me.sin_addr.s_addr = htonl(INADDR_ANY);

	if (bind(s, &si_me, sizeof(si_me))==-1) {
		diep("bind");
	}


    //serv.c:48:36: warning: passing argument 5 of ‘recvfrom’ from incompatible pointer type
    //if (recvfrom(s, buf, BUFLEN, 0, &si_other, &slen)==-1) {
	  //                                ^

	//recvfrom(sockfd, arrayReceived, sizeof(arrayReceived), 0, &addr, &addrlen);

  for (i=0; i<NPACK; i++) {
  	if (recvfrom(s, buf, BUFLEN, 0, &si_other, &slen)==-1) {
    	diep("recvfrom()");
		}
    
		//printf("Received packet from %s:%d\nData: %s\n\n", 
    //inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port), buf);
		
		printf("Received packet from %s:%d\n", 
    inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));

		for (t = 0; t < 16; t++) {
			//array[t] = ntohl(buf[t]);
			//printf("%d ", ntohl(buf[t]));
			printf("%d ", buf[t]);
		}
		printf("\n\n");


  }

	close(s);
	return 0;
}
