

#include<stdio.h>
#include<string.h>
#include <stdlib.h>

int main(void) {
		
		int intarray[5] = {0,1,2,3,4};
		char intstring[128];

		//char tempstring[10] = " ";
		int i;
		char tempstring[10] = " ";

		for (i=0; i<5; i++) {
			sprintf(tempstring, "%d", intarray[i]);
			strcat(intstring, tempstring);
			strcat(intstring, " ");		
		}

    printf("%s\n",intstring);
    return 0;
}
