#include <stdio.h>
#include <string.h>
#include<stdlib.h>


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<arpa/inet.h>
#include<sys/socket.h>



int main ()
{
   char str[50];
	 int i;
   strcpy(str,"This is string.h library function");
   puts(str);

   memset(str,'$',7);
   puts(str);


	const char expectedIP[] = "192.168.0.101";
	const char IP[] = "192.168.0.102";

	uint8_t buf[14] = {1,2,3,4,5,6,7,8,9,10,11,12,13,14};
	uint8_t msg[2];
	uint8_t hmac[4];
	uint8_t sig[8];

	
	memcpy(msg, buf, 2 * sizeof(int)); 
	uint8_t *temp = buf + 2;
	memcpy(hmac, temp, 4 * sizeof(int)); 



 
	uint8_t *temp2 = buf + 6;
	memcpy(sig, temp2, 8 * sizeof(int)); 



for (i = 0; i < 2; i++) {
		printf("%d ", msg[i]);
	}

	printf("\n");

	for (i = 0; i < 4; i++) {
		printf("%d ", hmac[i]);
	}

	printf("\n");

	for (i = 0; i < 8; i++) {
		printf("%d ", sig[i]);
	}

return(0);

}
