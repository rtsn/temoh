#include <openssl/engine.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>

#include<stdio.h> 
#include<string.h> 
#include<stdlib.h> 
#include<arpa/inet.h>
#include<sys/socket.h>
#include "uECC.h"
#include <time.h>
#include <sqlite3.h>

#include <openssl/engine.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>


#include <string.h>
#include <stdlib.h>



int main(void)
{
        unsigned char* key = (unsigned char*) "1";
        unsigned char* result;
        unsigned int result_len = 32;
        int i,a;
        HMAC_CTX ctx;
        result = (unsigned char*) malloc(sizeof(char) * result_len);
				unsigned char* data = (unsigned char*) "\xdd";
				uint8_t msg[16];

    		unsigned char* buffer;
				
				for (i=0;i<16; i++) {
					msg[i] = i;
				}

        ENGINE_load_builtin_engines();
        ENGINE_register_all_complete();

        HMAC_CTX_init(&ctx);
        HMAC_Init_ex(&ctx, key, 1, EVP_sha256(), NULL);


				//FUNKAR!!!!
				uint8_t *msgpointer = msg;
				unsigned char *char_pointer = (char*)msgpointer;

				for (i=0;i<16; i++) {
					HMAC_Update(&ctx, char_pointer+i, 1);


/*					a = msg[i];
					buffer[0] = a;
					HMAC_Update(&ctx, buffer, 1);
*/
				}

        HMAC_Final(&ctx, result, &result_len);
        HMAC_CTX_cleanup(&ctx);

				for (i=0; i <result_len; i++) {
					printf("%d ",result[i]);
				}
				printf("\n");


        return 0;
}
