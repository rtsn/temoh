#include <stdio.h>
#include <string.h>
#include <stdlib.h>


int main() {
	int msg[16];
	int i;
	for (i = 0; i < 16; i++) {
		msg[i] = 221;
	}


	char str[512];
	char bufman[218];



	for (i = 0; i < 16; i++) {
		//sprintf(bufman, "%x", msg[i]);
		sprintf(bufman, "0x%02x", msg[i]);
		strcat(str, bufman);
//		strcat(str, " ");
	}
	

	printf("%s\n", str);


}
