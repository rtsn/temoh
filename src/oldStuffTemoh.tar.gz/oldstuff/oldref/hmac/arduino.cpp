using namespace std;

#include <printf.h>
#include "sha256.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h> 
#include <iostream>
#include <string.h>

int main() {

	int msg[16];
	//uint8_t msg[16];
//	uint8_t* hashman;

	uint8_t hashman[4096];

	for (int i = 0; i < 8; i++) {
		msg[i] = i;
		printf("%d ",msg[i]);
	}
	printf("\n");

	//konvertera till str
	char datapata[512];
	char bufman[1];
	int i;
	for (i = 0; i < 8; i++) {
		sprintf(bufman, "%d", msg[i]);
		strcat(datapata, bufman);
		bufman[0] = '\0';
	}

	printf("%s\n", datapata);

	std::cout << "Tillverkat strang \n";
	
	uint8_t hmacKey[] = "1";

  Sha256.initHmac(hmacKey,1);
	for (i = 0; i < 16; i++) {
		Sha256.write(i);
	}
//	Sha256.print(datapata);
//	Sha256.print("0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd0xdd");

  std::cout << "Tillverkar hash\n";
	memcpy(hashman, Sha256.resultHmac(), 32); 
  std::cout << "hash ok\n";

/*
	printf("%d ",hashman[0]);
	printf("%d ",hashman[1]);
	printf("%d ",hashman[2]);
	printf("%d ",hashman[3]);
	printf("\n-------\n");

	printf("%d ",hashman[0]);
	printf("%d ",hashman[1]);
	printf("%d ",hashman[2]);
	printf("%d ",hashman[3]);
	
*/
	for (int i = 0; i < 32; i++) {
		printf("%d ",hashman[i]);
	}

	printf("\n");

}

