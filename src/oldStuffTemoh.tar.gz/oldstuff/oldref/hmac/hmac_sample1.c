
#include <stdio.h>
#include <string.h>
#include <openssl/hmac.h>
#include <stdlib.h>



int main()
{
    // The key to hash
    //char key[] = "1234567890";
		char key[] = "1";
		int i;

		int msg[16];
		char data[512] = {0};

		//memset(data,'0',16); 


		char bufman[218];
		bufman[0] = '\0';

		for (i = 0; i < 2; i++) {
			msg[i] = 221;
		}

		for (i = 0; i < 2; i++) {
			sprintf(bufman, "\\x%02x", msg[i]);
			strcat(data, bufman);
			bufman[0] = '\0';
		}

		printf("hashing: %s\n", data);
    

    unsigned char* digest;

		char data2[] = "\xdd\xdd";
    // Using sha1 hash engine here.
    // You may use other hash engines. e.g EVP_md5(), EVP_sha224, EVP_sha512, etc
    digest = HMAC(EVP_sha256(), key, strlen(key), (unsigned char*)data,strlen(data), NULL, NULL);    
		for (i = 0; i < 32; i++) {
			printf("%d ",digest[i]);
		}

		printf("\n");
		printf("\n");
		printf("\n");
		printf("\n");
		printf("\n");


    // Be careful of the length of string with the choosen hash engine. SHA1 produces a 20-byte hash value which rendered as 40 characters.
    // Change the length accordingly with your choosen hash engine
    char mdString[20];
		for(i = 0; i < 20; i++)
         sprintf(&mdString[i*2], "%02x", (unsigned int)digest[i]);

    printf("HMAC digest: %s\n", mdString);

    return 0;
}

