
#include <stdio.h>
#include <stdlib.h>
#include <sqlite3.h> 

static int callback(void *data, int argc, char **argv, char **azColName){
   int i;
   fprintf(stderr, "%s: ", (const char*)data);
   for(i=0; i<argc; i++){
      printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
   }
   printf("\n");
   return 0;
}

int main(int argc, char* argv[])
{
   sqlite3 *db;
   char *zErrMsg = 0;
   int rc;
   char *sql;
   const char* data = "Callback function called";

   /* Open database */
   rc = sqlite3_open("test.db", &db);
   if( rc ){
      fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
      exit(0);
   }else{
      fprintf(stderr, "Opened database successfully\n");
   }

   /* Create SQL statement */
	 sql = "select count(type) from sqlite_master where type='table' and name='MIMOSA';";

    sqlite3_stmt *statement;    
    if ( sqlite3_prepare(db, sql, -1, &statement, 0 ) == SQLITE_OK ) {
    	int res = 0;
    	res = sqlite3_step(statement);
    	
			if ( res == SQLITE_ROW ) {
    		char *s = (char*)sqlite3_column_text(statement, 0);
				printf("%s\n", s);
			 if (strcmp ("0", s) == 0) {
			printf("does not exist\n");

				}
       }
    }
	
	 sqlite3_close(db);
   return 0;
}

