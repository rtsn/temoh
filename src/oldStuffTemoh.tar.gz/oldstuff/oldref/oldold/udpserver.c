/*
 verbose flagga 
 config file
 	expectedip(?)
	port
	hmackey
	public ecc key
 logga
*/

#include<stdio.h>	
#include<string.h> 
#include<stdlib.h> 
#include<arpa/inet.h>
#include<sys/socket.h>
#include "uECC.h"
#include <time.h>
#include <sqlite3.h>
#include <openssl/engine.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>

#define BUFLEN 128 //Max length of buffer
#define PORT 8888	//The port on which to listen for incoming data
#define MSGLEN 16
#define HMACLEN 32
#define SIGLEN 64
#define PUBKEYLEN 64


#define ANSI_COLOR_RED     "\x1b[31m"
#define ANSI_COLOR_GREEN   "\x1b[32m"
#define ANSI_COLOR_YELLOW  "\x1b[33m"
#define ANSI_COLOR_BLUE    "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN    "\x1b[36m"
#define ANSI_COLOR_RESET   "\x1b[0m"

static int callback(void *NotUsed, int argc, char **argv, char **azColName) {
   int i;
   for(i=0; i<argc; i++){
      printf("%s = %s\n", azColName[i], argv[i] ? argv[i] : "NULL");
   }
   printf("\n");
   return 0;
}

void die(char *s) {
	perror(s);
	exit(1);
}

int hmacCheck(uint8_t msg[MSGLEN], uint8_t hmac[HMACLEN], unsigned char *key) {
				printf("\n- HMAC CHECK... ");
        unsigned char* result;
        unsigned int result_len = 32; 
        int i;
        HMAC_CTX ctx;
        result = (unsigned char*) malloc(sizeof(char) * result_len);
 
        ENGINE_load_builtin_engines();
        ENGINE_register_all_complete();

        HMAC_CTX_init(&ctx);
        HMAC_Init_ex(&ctx, key, 1, EVP_sha256(), NULL);
    
				uint8_t *msgpointer = msg;
				unsigned char *char_pointer = (unsigned char*)msgpointer;

        for (i=0;i<16; i++) {
					HMAC_Update(&ctx, char_pointer+i, 1);
        }

        HMAC_Final(&ctx, result, &result_len);
        HMAC_CTX_cleanup(&ctx);

				if (memcmp(result, hmac, result_len) != 0) {
					printf("Bad HMAC."); // expected
					return 0;
				}
				printf(ANSI_COLOR_GREEN "Good HMAC." ANSI_COLOR_RESET );
				return 1;
}

int ecdsaCheck(const uint8_t publickey[PUBKEYLEN], uint8_t hmac[HMACLEN], uint8_t sig[SIGLEN]) {
	printf("\n- ECDSA CHECK... ");
	const struct uECC_Curve_t * curve = uECC_secp160r1();
	if (!uECC_verify(publickey, hmac, HMACLEN, sig, curve)) {
		printf("Bad Sig. (uECC_verify() failed)  \n");
		return 0;
	}
	else {
		printf(ANSI_COLOR_GREEN "Good Sig."  ANSI_COLOR_RESET);
		return 1;
	}
}


char *getTimeStamp() {		
	struct tm *newtime;
	time_t aclock;
	time( &aclock ); /* Get time in seconds */
	newtime = localtime( &aclock ); /* Convert time to struct */
	char timestamp[30];
	sprintf(timestamp, asctime( newtime ));
	timestamp[strlen(timestamp) - 1] = 0; // remove \n
	char *tspointer = timestamp;
	return tspointer;
}

int addToDb(uint8_t msg[MSGLEN], char timestamp[], int verbose) {
  				sqlite3 *db;
					char *zErrMsg = 0;
   				int  rc,i;
   				//unsigned char *sql;
					char *sql;

	   			/* Open database */
  	 			rc = sqlite3_open("test.db", &db);
   				if( rc ){
      			fprintf(stderr, "Can't open database: %s\n", sqlite3_errmsg(db));
						return 0;
   				}
					else {
						if (verbose == 1) {
      				fprintf(stdout, "- Opened database successfully\n");
						}
   				}
				//Check if mimosa exists 
				sql = "select count(type) from sqlite_master where type='table' and name='MIMOSA';";
				sqlite3_stmt *statement;
				if ( sqlite3_prepare(db, sql, -1, &statement, 0 ) == SQLITE_OK ) {
					int res = 0;
					res = sqlite3_step(statement);
					if ( res == SQLITE_ROW ) {
						char *s = (char*)sqlite3_column_text(statement, 0);
						//printf("%s\n", s);
						
						if (strcmp ("0", s) == 0) {
							// if mimosa doesn't exist. create it!
   						sql = "CREATE TABLE MIMOSA("  \
         			"ID INTEGER PRIMARY KEY AUTOINCREMENT," \
         			"TIME  				 TEXT    NOT NULL," \
         			"DATA 					 TEXT    NOT NULL);"; 
											
   						/* Execute SQL statement */
   						rc = sqlite3_exec(db, sql, callback, 0, &zErrMsg);
   						if( rc != SQLITE_OK ){
   							fprintf(stderr, "SQL error: %s\n", zErrMsg);
      					sqlite3_free(zErrMsg);
								return 0;
   						}
							else	{
      					fprintf(stdout, "Table created successfully\n");
   						}
						}
					}
				}
				sqlite3_finalize(statement);
				char datadeluxe[65] = {0};
				char tempstring[10] = " ";
				//konverterar  msg till fin sträng
				for (i=0; i < MSGLEN; i++) {
        	sprintf(tempstring, "%d", msg[i]);
          strcat(datadeluxe, tempstring);
        	strcat(datadeluxe, " ");
				}
				datadeluxe[strlen(datadeluxe) - 1] = 0; 
				sql = "INSERT INTO MIMOSA (ID,TIME,DATA) " \
				"VALUES (NULL, '";
				char sql2[2038];
				strcpy(sql2,sql);
				strcat(sql2,timestamp);
				strcat(sql2, "','");
				strcat(sql2, datadeluxe);
				strcat(sql2, "');");
				if (verbose == 1) {
					printf("- sql= %s\n", sql2);
				}
   			// Execute SQL statement 
   			rc = sqlite3_exec(db, sql2, callback, 0, &zErrMsg);
   			if( rc != SQLITE_OK ){
      		fprintf(stderr, "SQL error: %s\n", zErrMsg);
      		sqlite3_free(zErrMsg);
					sqlite3_close(db);

					return 0;
   			}
				else {
					int output = sqlite3_last_insert_rowid(db);
					sqlite3_close(db);
					return output;
   			}
   			sqlite3_close(db);
}

int main(void) {

	int verbose = 1;
	struct sockaddr_in si_me, si_other;
	int s, i, recv_len;
	unsigned int slen = sizeof(si_other);
	
	uint8_t buf[BUFLEN];

	const uint8_t expectedIP[] = "192.168.0.111";
	unsigned char* hmacKey = (unsigned char*) "1";

	//create a UDP socket
	if ((s=socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP)) == -1) {
		die("socket");
	}
	
	// zero out the structure
	memset((char *) &si_me, 0, sizeof(si_me));
	
	si_me.sin_family = AF_INET;
	si_me.sin_port = htons(PORT);
	si_me.sin_addr.s_addr = htonl(INADDR_ANY);
	
	//bind socket to port
	if( bind(s , (struct sockaddr*)&si_me, sizeof(si_me) ) == -1) {
		die("bind");
	}
	
	//keep listening for data
	while(1) 	{
		uint8_t msg[MSGLEN];
		uint8_t hmac[HMACLEN];
		uint8_t sig[SIGLEN];
    char timestamp[30] = {0};
		printf("\n\nWaiting for data...\n\n");
		fflush(stdout);
		
		//try to receive some data, this is a blocking call
		if ((recv_len = recvfrom(s, buf, BUFLEN, 0, (struct sockaddr *) &si_other, &slen)) == -1) {
			die("recvfrom()");
		}
		
		//print details of the client/peer and the data received
		printf("Received packet from %s:%d\n", inet_ntoa(si_other.sin_addr), ntohs(si_other.sin_port));

		sprintf(timestamp, getTimeStamp(), 25);
		printf( "- Timestamp: %s\n", timestamp);

		//kolla-addr function?
		printf("- IP CHECK... ");
		if (memcmp(expectedIP, inet_ntoa(si_other.sin_addr), 13) != 0) {
			printf("Failed");
		}
		else {
			printf("OK!\n");
			
			printf("- MSG: ");
				for (i = 0; i < MSGLEN; i++) {
					msg[i] = buf[i];
					if (verbose == 1) {
						printf("%d ", msg[i]);
					}
				}
				if (verbose == 0) {
					printf("[omitted]");
				}

				printf("\n- HMAC: ");

				for (i = 0; i < HMACLEN; i++) {
					hmac[i] = buf[MSGLEN +i];
					if (verbose == 1) {
						printf("%d ", hmac[i]);
					}
				}
				if (verbose == 0) {
					printf("[omitted]");
				}

				printf("\n- SIG: ");

				for (i = 0; i < SIGLEN; i++) {
					sig[i] = buf[MSGLEN + HMACLEN + i];
					if (verbose == 1) {
						printf("%d ", sig[i]);
					}
				}

				if (verbose == 0) {
					printf("[omitted]");
				}

				const uint8_t publickey[64] =
				{121,111,188,74,140,239,209,189,153,65,212,107,118,19,119,136,147,218,157,255,171,223,94,123,250,221,159,
			 	128,205,198,255,204,181,94,144,183,249,128,185,28,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};


				if ((hmacCheck(msg,hmac,hmacKey) == 1) && (ecdsaCheck(publickey,hmac, sig) == 1)) {
					printf("\n- Inserting msg & timestamp into db:\n");
					int idreturn = addToDb(msg, timestamp, verbose);
					if ((idreturn != 0) && (verbose == 1)) {
						printf("- Records created successfully (ID: %d) \n",idreturn);
					}
				}
			}
		}

	//close(s);
	return 0;
}

