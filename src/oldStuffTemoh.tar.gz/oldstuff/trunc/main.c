#include <stdio.h>  
#include <string.h> 
#include <stdlib.h> 
#include <stdint.h>
#include <time.h>
#include <errno.h> //errno
#include <netinet/in.h> //sockaddr_in
#include <unistd.h>    //close


char * truncDigest(char *digest);
 
int main(int argc, char *argv[]) {

	char *dig = "796fbc4a8cefd1bd9941d46b7613778893da9dffabdf5e7bfadd9f80cdc6ffccb55e90b7f980b91c000000000000000000000000000000000000000000000000";

	printf("%s\n", dig);
	printf("%s\n", truncDigest(dig));
    
	return 0;
}

char * truncDigest(char *digest) {
    int zeroCounter = 0;
    char truncated[512];
    strcpy(truncated, digest);

    while (truncated[strlen(truncated) -1] == '0') {
        zeroCounter++;
        truncated[strlen(truncated) -1] = '\0';
    }

    char * s = malloc(snprintf(NULL, 0, "%s%s%d%s", truncated, "[",zeroCounter, "x0]") + 1);
    sprintf(s, "%s%s%d%s", truncated, "[",zeroCounter, "x0]") ;

    return s; 
}

