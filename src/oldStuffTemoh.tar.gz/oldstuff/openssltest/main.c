#include <openssl/engine.h>
#include <openssl/hmac.h>
#include <openssl/evp.h>
#include <stdio.h>  
#include <string.h> 
#include <stdlib.h> 
#include <stdint.h>

#define MSGLEN 16
#define HMACLEN 32


void createHmac(uint8_t msg[MSGLEN], uint8_t hmac[HMACLEN], unsigned char *key) {
    unsigned char* result;
    unsigned int result_len = HMACLEN; 
    int i;

    HMAC_CTX ctx;


    result = (unsigned char*) malloc(sizeof(char) * result_len);
 
    ENGINE_load_builtin_engines();
    ENGINE_register_all_complete();

    HMAC_CTX_init(&ctx);
    HMAC_Init_ex(&ctx, key, 1, EVP_sha256(), NULL);
    
    uint8_t *msgpointer = msg;
    unsigned char *char_pointer = (unsigned char*)msgpointer;

    for (i=0; i < MSGLEN; i++) {
        HMAC_Update(&ctx, char_pointer+i, 1); 
    }   

    HMAC_Final(&ctx, result, &result_len);
    HMAC_CTX_cleanup(&ctx);

    for (i=0; i < HMACLEN; i++) {
        hmac[i] = result[i];
    }   
}

int main(int argc, char *argv[]) {
	printf("hello world\n");

	uint8_t msg[MSGLEN];
 	uint8_t hmac[HMACLEN];
    int i;

	for (i = 0; i<MSGLEN; i++) {
		msg[i] = i;
	}

	unsigned char key[] = "1";
	createHmac(msg, hmac, key);

}


